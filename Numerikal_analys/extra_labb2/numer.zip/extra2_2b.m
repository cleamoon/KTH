xh = 1.5;
yh = 0;
zh = 0.25;
d = @(z) 50*(z+zh)*exp(-z/zh/2);
c = @(x,y, z) exp(-d(z)*((x-xh)^2+(y-yh)^2));
% 0 <= x <= 2, 0 <= y <= x/2 och 0 <= z <= 1
tol = 0.5*10^-6;
summa = 0;
for i = 0:tol:2
    for j= 0:tol:i
        for k = 0:tol:1
            summa = summa + tol*(c(i+tol,j,k)+c(i,j,k))/2*tol*(c(i,j,k)+c(i,j+tol,k)*tol*(c(i,j,k)+c(i,j,k+tol))/2)/2;
        end
    end
end
summa