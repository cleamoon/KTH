load('dollar.mat');
format long;
l = size(kurs);
l = l(1);
j = @(d1,d2,d3,d4,t,L) [-1; -t; sin(2*pi*t/L); cos(2*pi*t/L); 2*pi*t/L^2*(d4*sin(2*pi*t/L)-d3*cos(2*pi*t/L))];
f = @(d1,d2,d3,d4,t,L)  d1 + d2*t + d3*sin(2*pi*t/L) + d4*cos(2*pi*t/L);
d1t = 1;
d2t = 1;
d3t = 1;
d4t = 1;
Lt   = 100;

for i = 1:l
    fv = f(d1t, d2t, d3t, d4t, i, Lt);
    r = kurs(i) - fv;
    jv = j(d1t, d2t, d3t, d4t, i, Lt);
    B =  [d1t, d2t, d3t, d4t, Lt] + ((jv'*jv)\jv*r)';
    d1t = d1t + B(1);
    d2t = d2t + B(2);    
    d3t = d3t + B(3);    
    d4t = d4t + B(4);    
    Lt = Lt + B(5);
end

